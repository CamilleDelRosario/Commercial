package clothing;
// pasensya na eto lang kinaya ko huhu
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Clothing {
    static ArrayList<Item> inventory = new ArrayList<>();
static {
    inventory.add(new Item("LOOP T-Shirt", "loop1.jpg", 499));
    inventory.add(new Item("LOOP T-Shirt", "loop2.jpg", 499));
    inventory.add(new Item("LOOP T-Shirt", "loop3.jpg", 499));
    inventory.add(new Item("LOOP T-Shirt", "loop4.jpg", 499));
    inventory.add(new Item("LOOP T-Shirt", "loop5.jpg", 499));
    inventory.add(new Item("LOOP T-Shirt", "loop6.jpg", 499));
    inventory.add(new Item("ERROR T-Shirt", "error1.jpg", 399));
    inventory.add(new Item("ERROR T-Shirt", "error2.jpg", 399));
    inventory.add(new Item("HELLO WORLD T-Shirt", "hwts1.jpg", 399));
    inventory.add(new Item("HELLO WORLD T-Shirt", "HW1.jpg", 399));
    inventory.add(new Item("Boolean Sweat Shirt", "bl1.jpg", 599));
    inventory.add(new Item("I code T-shirt", "icode1.jpg", 350));
    inventory.add(new Item("I code T-shirt", "icode2.jpg", 350));
    inventory.add(new Item("Boolean Cup", "bl2_cup.jpg", 199));
    inventory.add(new Item("Boolean T-shirt", "bl3_tshirt.jpg", 499));
    inventory.add(new Item("Tech Shirt", "N1.jpg", 299));
    inventory.add(new Item("Tech Shirt", "N2.jpg", 299));
    inventory.add(new Item("Tech Shirt", "W1.jpg", 299));
    inventory.add(new Item("Tech Shirt", "W2.jpg", 299));
    inventory.add(new Item("Tech Shirt", "B1.jpg", 299));
    inventory.add(new Item("Tech Shirt", "B2.jpg", 299));
    inventory.add(new Item("</> Shirt", "slashB.jpg", 499));
    inventory.add(new Item("</> Shirt", "slashN.jpg", 499));
    inventory.add(new Item("</> Shirt", "slashW.jpg", 499));
}

    // Account Manager
    static class AdminAccountManager {
        private static HashMap<String, String> accounts = new HashMap<>();
        
      
    static {
        accounts.put("admin", "admin123");
        accounts.put("user", "user123");
    }
        public static boolean register(String username, String password) {
            if (accounts.containsKey(username)) return false;
            accounts.put(username, password);
            return true;
        }

        public static boolean login(String username, String password) {
            return accounts.containsKey(username) && accounts.get(username).equals(password);
        }
    }

  
    static class AdminLogin extends JFrame {
        private Image backgroundImage;

        public AdminLogin() {
           
            try {
                backgroundImage = new ImageIcon("bt.jpg").getImage();
            } catch (Exception e) {
                backgroundImage = null;
            }

            //Page Size
            setTitle("Admin Login");
            setSize(500, 400);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            //Background
            BackgroundPanel contentPanel = new BackgroundPanel();
            contentPanel.setLayout(new BorderLayout());
            setContentPane(contentPanel);

            JLabel titleLabel = new JLabel("Admin Portal", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Georgia", Font.BOLD, 26));
            titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
            titleLabel.setForeground(Color.WHITE);
            contentPanel.add(titleLabel, BorderLayout.NORTH);

            JPanel centerPanel = new JPanel(new GridLayout(4, 1, 10, 10));
            centerPanel.setOpaque(false);
            centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));

            JTextField usernameField = new JTextField();
            usernameField.setBorder(BorderFactory.createTitledBorder("Username"));
            JPasswordField passwordField = new JPasswordField();
            passwordField.setBorder(BorderFactory.createTitledBorder("Password"));

            centerPanel.add(usernameField);
            centerPanel.add(passwordField);

            JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
            buttonPanel.setOpaque(false);

            JButton loginBtn = new JButton("Login");
            JButton registerBtn = new JButton("Create Account");

            loginBtn.setBackground(new Color(70, 130, 180));
            loginBtn.setForeground(Color.WHITE);
            registerBtn.setBackground(new Color(60, 179, 113));
            registerBtn.setForeground(Color.WHITE);

            buttonPanel.add(loginBtn);
            buttonPanel.add(registerBtn);

            centerPanel.add(new JLabel());
            centerPanel.add(buttonPanel);

            contentPanel.add(centerPanel, BorderLayout.CENTER);

            loginBtn.addActionListener(e -> {
                String user = usernameField.getText();
                String pass = new String(passwordField.getPassword());
                if (AdminAccountManager.login(user, pass)) {
    JOptionPane.showMessageDialog(this, "Login successful!");
    if (user.equals("admin") || user.equals("manager")) {
        new AdminPanel(); 
    } else {
        new CustomerDashboard(); 
    }
    dispose();
}

            });

            registerBtn.addActionListener(e -> {
                new AdminRegister();
                dispose();
            });

            setVisible(true);
        }

        class BackgroundPanel extends JPanel {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    
                    Graphics2D g2d = (Graphics2D) g;
                    GradientPaint gradient = new GradientPaint(0, 0, new Color(70, 130, 180), 
                                                             0, getHeight(), new Color(30, 60, 120));
                    g2d.setPaint(gradient);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        }
    }

    // Admin Register ukininam
    static class AdminRegister extends JFrame {
        private Image backgroundImage;

        public AdminRegister() {
            try {
                backgroundImage = new ImageIcon("bt.jpg").getImage();
            } catch (Exception e) {
                backgroundImage = null;
            }

            setTitle("Create Admin Account");
            setSize(500, 400);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            BackgroundPanel contentPanel = new BackgroundPanel();
            contentPanel.setLayout(new BorderLayout());
            setContentPane(contentPanel);

            JLabel titleLabel = new JLabel("Register New Admin", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Georgia", Font.BOLD, 26));
            titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
            titleLabel.setForeground(Color.WHITE);
            contentPanel.add(titleLabel, BorderLayout.NORTH);

            JPanel centerPanel = new JPanel(new GridLayout(4, 1, 10, 10));
            centerPanel.setOpaque(false);
            centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));

            JTextField usernameField = new JTextField();
            usernameField.setBorder(BorderFactory.createTitledBorder("New Username"));
            JPasswordField passwordField = new JPasswordField();
            passwordField.setBorder(BorderFactory.createTitledBorder("New Password"));

            centerPanel.add(usernameField);
            centerPanel.add(passwordField);

            JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
            buttonPanel.setOpaque(false);

            JButton createBtn = new JButton("Create");
            JButton backBtn = new JButton("Back");

            createBtn.setBackground(new Color(60, 179, 113));
            createBtn.setForeground(Color.WHITE);
            backBtn.setBackground(new Color(220, 20, 60));
            backBtn.setForeground(Color.WHITE);

            buttonPanel.add(createBtn);
            buttonPanel.add(backBtn);

            centerPanel.add(new JLabel());
            centerPanel.add(buttonPanel);

            contentPanel.add(centerPanel, BorderLayout.CENTER);

            createBtn.addActionListener(e -> {
                String user = usernameField.getText().trim();
                String pass = new String(passwordField.getPassword());
                
                if (user.isEmpty() || pass.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Username and password cannot be empty.", 
                                                "Registration Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                if (AdminAccountManager.register(user, pass)) {
                    JOptionPane.showMessageDialog(this, "Account created! You can now login.");
                    new AdminLogin();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Username already taken.", 
                                                "Registration Failed", JOptionPane.ERROR_MESSAGE);
                }
            });

            backBtn.addActionListener(e -> {
                new AdminLogin();
                dispose();
            });

            setVisible(true);
        }
// magsingit lang ako ng comment dito baka gayahin ng iba edi may proof na tayo ang gumawa HAHAHAHAHA BSCS1A Group 1
        class BackgroundPanel extends JPanel {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                } else {
                    Graphics2D g2d = (Graphics2D) g;
                    GradientPaint gradient = new GradientPaint(0, 0, new Color(70, 130, 180), 
                                                             0, getHeight(), new Color(30, 60, 120));
                    g2d.setPaint(gradient);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        }
    }

static class CustomerDashboard extends JFrame {
    private Image backgroundImage;
    private JPanel itemPanel;

    public CustomerDashboard() {
        try {
            backgroundImage = new ImageIcon("bytestitch2.jpg").getImage();
        } catch (Exception e) {
            backgroundImage = null;
        }

        setTitle("Customer Dashboard - ByteStitch");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        BackgroundPanel contentPanel = new BackgroundPanel();
        contentPanel.setLayout(new BorderLayout());
        setContentPane(contentPanel);

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(180, 0));
        sidebar.setBackground(new Color(35, 45, 55));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JButton refreshBtn = createSidebarButton(" Refresh");
        JButton cartBtn = createSidebarButton(" Cart");
        JButton logoutBtn = createSidebarButton(" Log Out");

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(refreshBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        sidebar.add(cartBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 15)));
        sidebar.add(logoutBtn);
        sidebar.add(Box.createVerticalGlue());

        contentPanel.add(sidebar, BorderLayout.WEST);

        
        itemPanel = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 15));
        itemPanel.setOpaque(false);
        itemPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        refreshItems();

        JScrollPane scrollPane = new JScrollPane(itemPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Button listeners
        refreshBtn.addActionListener(e -> refreshItems());

        logoutBtn.addActionListener(e -> {
            new AdminLogin();
            dispose();
        });

        cartBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Cart feature coming soon!", "Cart", JOptionPane.INFORMATION_MESSAGE);
        });

        setVisible(true);
    }

    private void refreshItems() {
        itemPanel.removeAll();
        for (Item item : Clothing.inventory) {
            itemPanel.add(createItemCard(item.name, item.imagePath, item.price));
        }
        itemPanel.revalidate();
        itemPanel.repaint();
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(new Color(44, 62, 80));
        btn.setForeground(Color.WHITE);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(160, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JPanel createItemCard(String name, String imagePath, double price) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setPreferredSize(new Dimension(240, 300));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        card.setBackground(new Color(255, 255, 255, 200));
        card.setOpaque(true);

        JLabel nameLabel = new JLabel(name, SwingConstants.CENTER);
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        nameLabel.setOpaque(true);
        nameLabel.setBackground(new Color(240, 240, 240));

        JLabel imageLabel;
        try {
            ImageIcon icon = new ImageIcon(imagePath);
            if (icon.getIconWidth() > 0) {
                Image scaled = icon.getImage().getScaledInstance(200, 150, Image.SCALE_SMOOTH);
                imageLabel = new JLabel(new ImageIcon(scaled));
            } else throw new Exception("Image missing");
        } catch (Exception e) {
            imageLabel = new JLabel("Image Not Available", SwingConstants.CENTER);
            imageLabel.setPreferredSize(new Dimension(200, 150));
            imageLabel.setOpaque(true);
            imageLabel.setBackground(new Color(240, 240, 240));
            imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        }

        JLabel priceLabel = new JLabel("₱" + price, SwingConstants.CENTER);
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        priceLabel.setOpaque(true);
        priceLabel.setBackground(new Color(46, 134, 193));
        priceLabel.setForeground(Color.WHITE);

        JButton orderBtn = new JButton("🛍 ORDER");
        orderBtn.setFocusPainted(false);
        orderBtn.setBackground(new Color(39, 174, 96));
        orderBtn.setForeground(Color.WHITE);
        orderBtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        orderBtn.addActionListener(e -> {
            String itemInfo = String.format("You ordered: %s\nPrice: ₱%.2f", name, price);
            JOptionPane.showMessageDialog(this, itemInfo, "Order Placed", JOptionPane.INFORMATION_MESSAGE);
        });

        JPanel bottomPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        bottomPanel.setOpaque(false);
        bottomPanel.add(priceLabel);
        bottomPanel.add(orderBtn);

        card.add(nameLabel, BorderLayout.NORTH);
        card.add(imageLabel, BorderLayout.CENTER);
        card.add(bottomPanel, BorderLayout.SOUTH);

        return card;
    }

    class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(100, 150, 200),
                        0, getHeight(), new Color(50, 80, 120));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }
}

static class AdminPanel extends JFrame {
    private Image backgroundImage;
    private JPanel itemPanel;

    public AdminPanel() {
        try {
            backgroundImage = new ImageIcon("bytestitch2.jpg").getImage();
        } catch (Exception e) {
            backgroundImage = null;
        }

        setTitle("Admin Panel - ByteStitch");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        BackgroundPanel contentPanel = new BackgroundPanel();
        contentPanel.setLayout(new BorderLayout());
        setContentPane(contentPanel);

        // Sidebar
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(180, 0));
        sidebar.setBackground(new Color(28, 40, 51));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JButton addItemBtn = createSidebarButton(" Add Item");
        JButton logoutBtn = createSidebarButton(" Log Out");

        sidebar.add(Box.createVerticalGlue());
        sidebar.add(addItemBtn);
        sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
        sidebar.add(logoutBtn);
        sidebar.add(Box.createVerticalGlue());

        contentPanel.add(sidebar, BorderLayout.WEST);

        // Items Panel
        itemPanel = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 15));
        itemPanel.setOpaque(false);
        itemPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        refreshItems();

        JScrollPane scrollPane = new JScrollPane(itemPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // smooth scroll
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Button actions
        logoutBtn.addActionListener(e -> {
            new AdminLogin();
            dispose();
        });
        

        addItemBtn.addActionListener(e -> showAddItemDialog());

        setVisible(true);
    }

    private JButton createSidebarButton(String text) {
        JButton btn = new JButton(text);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(new Color(44, 62, 80));
        btn.setForeground(Color.WHITE);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(160, 45));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void showAddItemDialog() {
        JTextField nameField = new JTextField();
        JTextField imageField = new JTextField();
        JTextField priceField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Item Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Image Filename (e.g., shirt.jpg):"));
        panel.add(imageField);
        panel.add(new JLabel("Price (₱):"));
        panel.add(priceField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Item", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String image = imageField.getText().trim();
            String priceText = priceField.getText().trim();

            if (name.isEmpty() || image.isEmpty() || priceText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double price = Double.parseDouble(priceText);
                inventory.add(new Item(name, image, price));
                refreshItems();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid price.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshItems() {
        itemPanel.removeAll();
        for (Item item : inventory) {
            itemPanel.add(createItemCard(item));
        }
        itemPanel.revalidate();
        itemPanel.repaint();
    }
// comment ulit ako dine hehe
    private JPanel createItemCard(Item item) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setPreferredSize(new Dimension(240, 300));

        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        card.setBackground(new Color(255, 255, 255, 215));
        card.setOpaque(true);

        JLabel nameLabel = new JLabel(item.name, SwingConstants.CENTER);
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        nameLabel.setOpaque(true);
        nameLabel.setBackground(new Color(240, 240, 240));
        nameLabel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

        JLabel imageLabel;
        try {
            ImageIcon icon = new ImageIcon(item.imagePath);
            if (icon.getIconWidth() > 0) {
                Image scaled = icon.getImage().getScaledInstance(200, 150, Image.SCALE_SMOOTH);
                imageLabel = new JLabel(new ImageIcon(scaled));
            } else throw new Exception("Image missing");
        } catch (Exception e) {
            imageLabel = new JLabel("Image Not Available", SwingConstants.CENTER);
            imageLabel.setPreferredSize(new Dimension(200, 150));
            imageLabel.setOpaque(true);
            imageLabel.setBackground(new Color(240, 240, 240));
            imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        }

        JLabel priceLabel = new JLabel("₱" + item.price, SwingConstants.CENTER);
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        priceLabel.setOpaque(true);
        priceLabel.setBackground(new Color(52, 152, 219));
        priceLabel.setForeground(Color.WHITE);

        JButton deleteBtn = new JButton("🗑 Delete");
        deleteBtn.setFocusPainted(false);
        deleteBtn.setBackground(new Color(231, 76, 60));
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        deleteBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        deleteBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this item?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                inventory.remove(item);
                refreshItems();
            }
        });

        JPanel bottomPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        bottomPanel.setOpaque(false);
        bottomPanel.add(priceLabel);
        bottomPanel.add(deleteBtn);

        card.add(nameLabel, BorderLayout.NORTH);
        card.add(imageLabel, BorderLayout.CENTER);
        card.add(bottomPanel, BorderLayout.SOUTH);

        return card;
    }

    class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(100, 150, 200),
                        0, getHeight(), new Color(50, 80, 120));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }
}


static class Item {
    String name;
    String imagePath;
    double price;

    Item(String name, String imagePath, double price) {
        this.name = name;
        this.imagePath = imagePath;
        this.price = price;
    }
}

  
    static class WrapLayout extends FlowLayout {
        public WrapLayout() {
            super();
        }

        public WrapLayout(int align) {
            super(align);
        }

        public WrapLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            return layoutSize(target, false);
        }

        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int targetWidth = target.getWidth();
                if (targetWidth == 0) targetWidth = Integer.MAX_VALUE;

                Insets insets = target.getInsets();
                int maxWidth = targetWidth - insets.left - insets.right - getHgap() * 2;

                Dimension dim = new Dimension(0, 0);
                int rowWidth = 0;
                int rowHeight = 0;

                for (Component comp : target.getComponents()) {
                    if (!comp.isVisible()) continue;

                    Dimension d = preferred ? comp.getPreferredSize() : comp.getMinimumSize();

                    if (rowWidth + d.width > maxWidth) {
                        dim.width = Math.max(dim.width, rowWidth);
                        dim.height += rowHeight + getVgap();
                        rowWidth = d.width;
                        rowHeight = d.height;
                    } else {
                        rowWidth += d.width + getHgap();
                        rowHeight = Math.max(rowHeight, d.height);
                    }
                }

                dim.width = Math.max(dim.width, rowWidth);
                dim.height += rowHeight;

                dim.width += insets.left + insets.right;
                dim.height += insets.top + insets.bottom;

                return dim;
            }
        }
    }

    public Clothing() {
       
        new AdminLogin();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Clothing());
    }
}